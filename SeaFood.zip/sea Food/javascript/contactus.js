// Wait for the DOM to fully load before attaching event listeners
document.addEventListener("DOMContentLoaded", function() {
    // Get the form and success message elements
    const form = document.querySelector("form");
    const successMessage = document.createElement('div');
    successMessage.classList.add('success-message');
    successMessage.textContent = "Form submitted successfully!";
    successMessage.style.display = 'none'; // Hide message initially
    form.insertAdjacentElement('afterend', successMessage); // Insert message after the form

    // Listen for the form submission
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent page reload on form submit
        
        // Show success message
        successMessage.style.display = 'block';

        // Optionally, clear the form
        form.reset();
        
        // Hide the success message after 3 seconds
        setTimeout(function() {
            successMessage.style.display = 'none';
        }, 3000); // Message disappears after 3 seconds
    });
});

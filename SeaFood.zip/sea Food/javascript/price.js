function searchTable() {
    // Get the search input value and convert to uppercase for case-insensitive search
    let input = document.getElementById("searchBar").value.toUpperCase();
    let table = document.getElementById("priceTable");
    let tr = table.getElementsByTagName("tr");

    // Loop through all table rows, excluding the first (header) row
    for (let i = 1; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName("td")[0]; // Select the country name column
        if (td) {
            let txtValue = td.textContent || td.innerText;
            // Toggle row visibility based on whether it matches the search term
            tr[i].style.display = txtValue.toUpperCase().includes(input) ? "" : "none";
        }
    }
}